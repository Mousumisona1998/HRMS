from django.urls import path
from . import views

app_name = 'resignation'

urlpatterns = [
    path('dashboard/', views.resignation_dashboard, name='dashboard'),
    path('submit/', views.submit_resignation, name='submit_resignation'),
    path('all/', views.all_resignations, name='all_resignations'),
    path('my-resignation/', views.my_resignation, name='my_resignation'),
    path('detail/<int:resignation_id>/', views.resignation_detail, name='resignation_detail'),
    path('approve/<int:resignation_id>/', views.approve_resignation, name='approve_resignation'),
    path('checklist/<int:checklist_id>/update/', views.update_checklist, name='update_checklist'),
    path('analytics/', views.resignation_analytics, name='analytics'),
]