from django.db import models
from hr.models import Employee

class Resignation(models.Model):
    RESIGNATION_STATUS = [
        ('applied', 'Applied'),
        ('under_review', 'Under Review'),
        ('accepted', 'Accepted'),
        ('rejected', 'Rejected'),
        ('withdrawn', 'Withdrawn'),
        ('completed', 'Completed'),
    ]
    
    EXIT_STATUS = [
        ('serving_notice', 'Serving Notice Period'),
        ('notice_completed', 'Notice Period Completed'),
        ('immediate', 'Immediate Exit'),
        ('buyout', 'Notice Period Buyout'),
    ]
    
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    resignation_date = models.DateField()
    last_working_date = models.DateField()
    reason = models.TextField()
    feedback = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=20, choices=RESIGNATION_STATUS, default='applied')
    exit_status = models.CharField(max_length=20, choices=EXIT_STATUS, default='serving_notice')
    
    # Approval workflow
    applied_to = models.ForeignKey(Employee, on_delete=models.SET_NULL, null=True, blank=True, related_name='resignations_received')
    approved_by = models.ForeignKey(Employee, on_delete=models.SET_NULL, null=True, blank=True, related_name='resignations_approved')
    approved_date = models.DateField(null=True, blank=True)
    
    # Notice period details
    notice_period_days = models.IntegerField(default=60)
    actual_notice_days = models.IntegerField(default=0)
    notice_period_start = models.DateField(null=True, blank=True)
    notice_period_end = models.DateField(null=True, blank=True)
    
    # Exit details
    exit_interview_date = models.DateField(null=True, blank=True)
    exit_interview_conducted_by = models.ForeignKey(Employee, on_delete=models.SET_NULL, null=True, blank=True, related_name='exit_interviews')
    exit_interview_notes = models.TextField(blank=True, null=True)
    
    # Financial details
    pending_salary = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    pending_bonus = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    deductions = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    final_settlement = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    
    # System fields
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'resignation_resignation'
    
    def __str__(self):
        return f"{self.employee} - {self.resignation_date}"

class ResignationChecklist(models.Model):
    resignation = models.ForeignKey(Resignation, on_delete=models.CASCADE)
    task_name = models.CharField(max_length=200)
    department = models.CharField(max_length=100)
    assigned_to = models.ForeignKey(Employee, on_delete=models.SET_NULL, null=True, blank=True)
    due_date = models.DateField()
    completed = models.BooleanField(default=False)
    completed_date = models.DateField(null=True, blank=True)
    remarks = models.TextField(blank=True, null=True)
    
    class Meta:
        db_table = 'resignation_checklist'

class ResignationDocument(models.Model):
    resignation = models.ForeignKey(Resignation, on_delete=models.CASCADE)
    document_type = models.CharField(max_length=100)
    document_file = models.FileField(upload_to='resignation_documents/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'resignation_documents'