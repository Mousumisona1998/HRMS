from django.shortcuts import render, redirect, get_object_or_404
from django.db import models
from django.contrib import messages
from django.http import JsonResponse
from django.db.models import Q
from datetime import date, timedelta
from datetime import date, timedelta, datetime
from django.utils import timezone
from .models import Resignation, ResignationChecklist, ResignationDocument
from hr.models import Employee

def resignation_dashboard(request):
    """Comprehensive resignation dashboard with WOW features"""
    if not request.session.get('user_authenticated'):
        return redirect('login')
    
    user_role = request.session.get('user_role')
    user_email = request.session.get('user_email')
    
    # Statistics
    total_resignations = Resignation.objects.count()
    pending_resignations = Resignation.objects.filter(status='applied').count()
    active_notice = Resignation.objects.filter(exit_status='serving_notice').count()
    completed_this_month = Resignation.objects.filter(
        status='completed',
        created_at__month=date.today().month,
        created_at__year=date.today().year
    ).count()
    
    # Recent resignations with employee details
    recent_resignations = Resignation.objects.select_related('employee').order_by('-created_at')[:10]
    
    # For employees, show only their resignation
    my_resignation = None
    if user_role == 'EMPLOYEE':
        try:
            employee = Employee.objects.get(email=user_email)
            my_resignation = Resignation.objects.filter(employee=employee).first()
        except Employee.DoesNotExist:
            pass
    
    context = {
        'total_resignations': total_resignations,
        'pending_resignations': pending_resignations,
        'active_notice': active_notice,
        'completed_this_month': completed_this_month,
        'recent_resignations': recent_resignations,
        'my_resignation': my_resignation,
        'user_role': user_role,
        'today_date': date.today(),
    }
    return render(request, 'resignation/dashboard.html', context)

def submit_resignation(request):
    """Employee submits resignation with automatic calculations"""
    if not request.session.get('user_authenticated'):
        return redirect('login')
    
    if request.method == 'POST':
        try:
            employee = Employee.objects.get(email=request.session.get('user_email'))
            resignation_date = request.POST.get('resignation_date')
            last_working_date = request.POST.get('last_working_date')
            reason = request.POST.get('reason')
            
            # Convert dates
            resignation_date_obj = datetime.strptime(resignation_date, '%Y-%m-%d').date()
            last_working_date_obj = datetime.strptime(last_working_date, '%Y-%m-%d').date()
            
            # Calculate notice period with safe default
            notice_days = (last_working_date_obj - resignation_date_obj).days
            
            # Use employee's notice period or default to 60 days
            employee_notice_period = getattr(employee, 'notice_period_days', 60)
            if employee_notice_period is None:
                employee_notice_period = 60
                
            actual_notice_days = min(notice_days, employee_notice_period)
            
            # Get reporting manager safely - FIXED VERSION
            applied_to = None
            if hasattr(employee, 'reporting_manager_id') and employee.reporting_manager_id:
                try:
                    applied_to = Employee.objects.get(employee_id=employee.reporting_manager_id)
                except Employee.DoesNotExist:
                    pass
            
            # If no reporting manager found, try to get from reporting_manager field
            if not applied_to and hasattr(employee, 'reporting_manager') and employee.reporting_manager:
                try:
                    # Try to find manager by name (fallback)
                    manager_name = employee.reporting_manager
                    if ' (' in manager_name:
                        manager_name = manager_name.split(' (')[0]
                    
                    # Try to find by first name and last name
                    name_parts = manager_name.split(' ')
                    if len(name_parts) >= 2:
                        applied_to = Employee.objects.filter(
                            first_name=name_parts[0],
                            last_name=name_parts[1],
                            status='active'
                        ).first()
                except:
                    pass
            
            # Final fallback - get any HR/Admin user
            if not applied_to:
                try:
                    applied_to = Employee.objects.filter(
                        role__in=['HR', 'ADMIN', 'SUPER_ADMIN'],
                        status='active'
                    ).first()
                except:
                    applied_to = None
            
            resignation = Resignation(
                employee=employee,
                resignation_date=resignation_date_obj,
                last_working_date=last_working_date_obj,
                reason=reason,
                applied_to=applied_to,  # This should now be an Employee object or None
                notice_period_days=employee_notice_period,
                actual_notice_days=actual_notice_days,
                notice_period_start=resignation_date_obj,
                notice_period_end=last_working_date_obj
            )
            resignation.save()
            
            # Auto-create comprehensive checklist
            create_resignation_checklist(resignation)
            
            messages.success(request, '🎉 Resignation submitted successfully! HR will review your application.')
            return redirect('resignation:dashboard')
            
        except Exception as e:
            messages.error(request, f'Error submitting resignation: {str(e)}')
            print(f"Resignation submission error: {str(e)}")  # For debugging
    
    # GET request - show form
    try:
        employee = Employee.objects.get(email=request.session.get('user_email'))
        # Safe defaults for notice period
        employee_notice_period = getattr(employee, 'notice_period_days', 60)
        if employee_notice_period is None:
            employee_notice_period = 60
            
        min_date = (date.today() + timedelta(days=1)).strftime('%Y-%m-%d')
        max_date = (date.today() + timedelta(days=employee_notice_period)).strftime('%Y-%m-%d')
    except Employee.DoesNotExist:
        min_date = date.today().strftime('%Y-%m-%d')
        max_date = (date.today() + timedelta(days=60)).strftime('%Y-%m-%d')
        employee_notice_period = 60
    
    context = {
        'min_date': min_date,
        'max_date': max_date,
        'notice_period': employee_notice_period,
        'user_name': request.session.get('user_name'),
        'user_role': request.session.get('user_role'),
        'today_date': date.today(),
    }
    return render(request, 'resignation/submit_resignation.html', context)

def create_resignation_checklist(resignation):
    """Auto-create comprehensive exit checklist"""
    checklist_items = [
        {'task': 'Exit Interview Scheduling', 'department': 'HR', 'days': 2},
        {'task': 'Knowledge Transfer Documentation', 'department': 'Department', 'days': 7},
        {'task': 'Project Handover', 'department': 'Department', 'days': 5},
        {'task': 'Laptop & Asset Return', 'department': 'IT', 'days': 1},
        {'task': 'ID Card Surrender', 'department': 'HR', 'days': 1},
        {'task': 'Email Account Deactivation', 'department': 'IT', 'days': 0},
        {'task': 'Access Card Deactivation', 'department': 'Admin', 'days': 0},
        {'task': 'Final Salary Processing', 'department': 'Finance', 'days': 3},
        {'task': 'Experience Letter Preparation', 'department': 'HR', 'days': 5},
        {'task': 'Clear Dues from Departments', 'department': 'Finance', 'days': 2},
    ]
    
    for item in checklist_items:
        ResignationChecklist.objects.create(
            resignation=resignation,
            task_name=item['task'],
            department=item['department'],
            due_date=resignation.last_working_date - timedelta(days=item['days'])
        )

def all_resignations(request):
    """View all resignations with advanced filters"""
    if not request.session.get('user_authenticated'):
        return redirect('login')
    
    resignations = Resignation.objects.select_related('employee', 'applied_to', 'approved_by').all()
    
    # Advanced filters
    status_filter = request.GET.get('status')
    department_filter = request.GET.get('department')
    date_from = request.GET.get('date_from')
    date_to = request.GET.get('date_to')
    
    if status_filter:
        resignations = resignations.filter(status=status_filter)
    if department_filter:
        resignations = resignations.filter(employee__department=department_filter)
    if date_from:
        resignations = resignations.filter(resignation_date__gte=date_from)
    if date_to:
        resignations = resignations.filter(resignation_date__lte=date_to)
    
    # Search
    search_query = request.GET.get('search')
    if search_query:
        resignations = resignations.filter(
            Q(employee__first_name__icontains=search_query) |
            Q(employee__last_name__icontains=search_query) |
            Q(employee__employee_id__icontains=search_query) |
            Q(reason__icontains=search_query)
        )
    
    context = {
        'resignations': resignations.order_by('-created_at'),
        'status_choices': Resignation.RESIGNATION_STATUS,
        'departments': Employee.objects.values_list('department', flat=True).distinct(),
        'user_name': request.session.get('user_name'),
        'user_role': request.session.get('user_role'),
        'today_date': date.today(),
    }
    return render(request, 'resignation/all_resignations.html', context)

def my_resignation(request):
    """Employee views their own resignation"""
    if not request.session.get('user_authenticated'):
        return redirect('login')
    
    try:
        employee = Employee.objects.get(email=request.session.get('user_email'))
        resignation = Resignation.objects.filter(employee=employee).first()
        checklist = ResignationChecklist.objects.filter(resignation=resignation) if resignation else []
        documents = ResignationDocument.objects.filter(resignation=resignation) if resignation else []
    except Employee.DoesNotExist:
        resignation = None
        checklist = []
        documents = []
    
    context = {
        'resignation': resignation,
        'checklist': checklist,
        'documents': documents,
        'user_name': request.session.get('user_name'),
        'user_role': request.session.get('user_role'),
        'today_date': date.today(),
    }
    return render(request, 'resignation/my_resignation.html', context)

def resignation_detail(request, resignation_id):
    """Detailed view of resignation with full workflow"""
    if not request.session.get('user_authenticated'):
        return redirect('login')
    
    resignation = get_object_or_404(
        Resignation.objects.select_related('employee', 'applied_to', 'approved_by', 'exit_interview_conducted_by'),
        id=resignation_id
    )
    checklist = ResignationChecklist.objects.filter(resignation=resignation).select_related('assigned_to')
    documents = ResignationDocument.objects.filter(resignation=resignation)
    
    # Check permissions
    user_role = request.session.get('user_role')
    user_email = request.session.get('user_email')
    
    if user_role == 'EMPLOYEE' and resignation.employee.email != user_email:
        messages.error(request, 'You can only view your own resignation details.')
        return redirect('access_denied')
    
    context = {
        'resignation': resignation,
        'checklist': checklist,
        'documents': documents,
        'user_name': request.session.get('user_name'),
        'user_role': user_role,
        'today_date': date.today(),
    }
    return render(request, 'resignation/resignation_detail.html', context)

def approve_resignation(request, resignation_id):
    """Approve/reject resignation with workflow"""
    if not request.session.get('user_authenticated'):
        return redirect('login')
    
    if request.method == 'POST':
        resignation = get_object_or_404(Resignation, id=resignation_id)
        action = request.POST.get('action')
        remarks = request.POST.get('remarks', '')
        
        try:
            approver = Employee.objects.get(email=request.session.get('user_email'))
            
            if action == 'approve':
                resignation.status = 'accepted'
                resignation.approved_by = approver
                resignation.approved_date = date.today()
                resignation.feedback = remarks
                messages.success(request, '✅ Resignation approved successfully!')
                
            elif action == 'reject':
                resignation.status = 'rejected'
                resignation.feedback = remarks
                messages.success(request, '❌ Resignation rejected!')
            
            elif action == 'schedule_exit':
                interview_date = request.POST.get('interview_date')
                if interview_date:
                    resignation.exit_interview_date = interview_date
                    resignation.exit_interview_conducted_by = approver
                    messages.success(request, '📅 Exit interview scheduled!')
            
            resignation.save()
            
        except Exception as e:
            messages.error(request, f'Error processing resignation: {str(e)}')
    
    return redirect('resignation:resignation_detail', resignation_id=resignation_id)

def update_checklist(request, checklist_id):
    """Update checklist item status"""
    if not request.session.get('user_authenticated'):
        return JsonResponse({'success': False, 'error': 'Not authenticated'})
    
    if request.method == 'POST':
        try:
            checklist_item = get_object_or_404(ResignationChecklist, id=checklist_id)
            completed = request.POST.get('completed') == 'true'
            remarks = request.POST.get('remarks', '')
            
            checklist_item.completed = completed
            checklist_item.completed_date = date.today() if completed else None
            checklist_item.remarks = remarks
            checklist_item.save()
            
            return JsonResponse({'success': True, 'completed': completed})
            
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    
    return JsonResponse({'success': False, 'error': 'Invalid method'})

def resignation_analytics(request):
    """Advanced analytics for resignations"""
    if not request.session.get('user_authenticated'):
        return redirect('login')
    
    # Monthly trends
    current_year = date.today().year
    monthly_data = []
    for month in range(1, 13):
        count = Resignation.objects.filter(
            created_at__year=current_year,
            created_at__month=month
        ).count()
        monthly_data.append(count)
    
    # Department-wise analysis
    dept_data = []
    departments = Employee.objects.values_list('department', flat=True).distinct()
    for dept in departments:
        if dept:
            count = Resignation.objects.filter(employee__department=dept).count()
            dept_data.append({'department': dept, 'count': count})
    
    # Reason analysis
    reasons = Resignation.objects.values('reason').annotate(count=models.Count('id')).order_by('-count')[:10]
    
    # Calculate totals for templates
    total_reasons = sum(reason['count'] for reason in reasons)
    total_dept_count = sum(dept['count'] for dept in dept_data)
    
    context = {
        'monthly_data': monthly_data,
        'dept_data': dept_data,
        'reasons': reasons,
        'total_reasons': total_reasons,
        'total_dept_count': total_dept_count,
        'user_name': request.session.get('user_name'),
        'user_role': request.session.get('user_role'),
        'today_date': date.today(),
    }
    return render(request, 'resignation/analytics.html', context)